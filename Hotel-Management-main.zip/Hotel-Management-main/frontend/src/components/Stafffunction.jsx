import React from "react";

function Stafffunction(){
   
    return(
        <div>
            <h2>
                <a href="/ShowBooking" alt='Bookings'>Reservations..</a>
                <a href="/ShowHousekeeping" alt='Housekeeping'>HouseKeeping requestes..</a>
                <a href="/ShowFeedback" alt='Feedback'>Feedbacks..</a>

                                    
            </h2>
        </div>

    )
}
export default Stafffunction;